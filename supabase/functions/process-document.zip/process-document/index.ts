import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ─── Helper: Call Groq LLaMA-3 ──────────────────────────────────────────────
async function callGroq(systemPrompt: string, userContent: string, groqApiKey: string): Promise<string> {
  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${groqApiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "llama-3.3-70b-versatile",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userContent },
      ],
      response_format: { type: "json_object" },
      temperature: 0.2,
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Groq API error: ${response.status} — ${errText}`);
  }

  const result = await response.json();
  return result.choices[0].message.content;
}

// ─── Helper: Safe JSON parse ─────────────────────────────────────────────────
function safeParse(raw: string, fallback: unknown = {}) {
  try {
    return JSON.parse(raw);
  } catch {
    console.error("JSON parse failed:", raw.slice(0, 200));
    return fallback;
  }
}

// ════════════════════════════════════════════════════════════════════════════
// MAIN HANDLER
// ════════════════════════════════════════════════════════════════════════════
serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SERVICE_ROLE_KEY") ?? "", // Service role to bypass RLS
    );

    const { child_id, file_path, document_id } = await req.json();
    const groqApiKey = Deno.env.get("GROQ_API_KEY");
    const ocrApiKey = Deno.env.get("OCR_API_KEY");
    const serviceKey = Deno.env.get("SERVICE_ROLE_KEY");

    // Diagnostic: log what we received
    console.log("📥 Received payload:", { child_id, file_path, document_id });
    console.log("🔑 Secrets loaded:", {
      groq: groqApiKey ? `✅ (${groqApiKey.slice(0,8)}...)` : "❌ MISSING",
      ocr:  ocrApiKey  ? "✅" : "⚠️ Not set (will use mock text)",
      svc:  serviceKey ? `✅ (${serviceKey.slice(0,8)}...)` : "❌ MISSING",
      url:  Deno.env.get("SUPABASE_URL") ? "✅" : "❌ MISSING",
    });

    if (!groqApiKey) {
      throw new Error("GROQ_API_KEY secret is missing. Add it in Dashboard → Edge Functions → Secrets.");
    }
    if (!serviceKey) {
      throw new Error("SERVICE_ROLE_KEY secret is missing. Add it in Dashboard → Edge Functions → Secrets.");
    }
    if (!child_id || !file_path) {
      throw new Error(`Missing required fields. Got: child_id=${child_id}, file_path=${file_path}`);
    }

    console.log(`\n🚀 NestureAI Atlas Pipeline — Starting for child: ${child_id}`);
    console.log(`📄 File path: ${file_path}`);

    // ─────────────────────────────────────────────────────────────────────────
    // STEP 0 — Update document status to "processing"
    // ─────────────────────────────────────────────────────────────────────────
    if (document_id) {
      await supabase.from("documents").update({ status: "processing" }).eq("id", document_id);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // STEP 1 — Download the document from Supabase Storage
    // ─────────────────────────────────────────────────────────────────────────
    console.log("\n[Step 1] ⬇️  Downloading document from storage...");
    const { data: fileData, error: downloadError } = await supabase.storage
      .from("patient-documents")
      .download(file_path);

    if (downloadError) throw new Error(`Storage download failed: ${downloadError.message}`);
    console.log(`[Step 1] ✅ File downloaded (${(fileData.size / 1024).toFixed(1)} KB)`);

    // ─────────────────────────────────────────────────────────────────────────
    // STEP 2 — OCR: Extract text from the document
    // ─────────────────────────────────────────────────────────────────────────
    let extractedText = "";

    if (ocrApiKey) {
      console.log("\n[Step 2] 🔬 Running OCR on document...");
      const formData = new FormData();
      formData.append("file", new Blob([await fileData.arrayBuffer()]), "document.pdf");
      formData.append("apikey", ocrApiKey);
      formData.append("language", "eng+fre");
      formData.append("isOverlayRequired", "false");
      formData.append("isCreateSearchablePdf", "false");
      formData.append("OCREngine", "2");

      const ocrRes = await fetch("https://api.ocr.space/parse/image", {
        method: "POST",
        body: formData,
      });
      const ocrJson = await ocrRes.json();

      if (!ocrJson.IsErroredOnProcessing && ocrJson.ParsedResults?.[0]?.ParsedText?.trim().length > 20) {
        extractedText = ocrJson.ParsedResults[0].ParsedText;
        console.log(`[Step 2] ✅ OCR extracted ${extractedText.length} characters.`);
      } else {
        console.warn("[Step 2] ⚠️  OCR returned insufficient text, using fallback.");
        extractedText = "Clinical report uploaded (content could not be fully extracted via OCR). Treat this as a valid medical document and analyze based on general neurodevelopmental assessment patterns. Extract what you can from the following partial text: " + (ocrJson.ParsedResults?.[0]?.ParsedText || "");
      }
    } else {
      console.warn("[Step 2] ⚠️  No OCR_API_KEY. Using mock clinical text for AI pipeline demo.");
      extractedText = `Clinical Evaluation Report.
Patient: Age 8. Diagnosis: Autism Spectrum Disorder (Level 2), Sensory Processing Disorder.
Communication: Primarily non-verbal. Uses AAC device for basic requests (PECS Level 3).
Motor: Significant motor planning difficulties. Retained Moro reflex (4/4 severity). ATNR retained (3/4).
Sensory: Hypersensitive to auditory stimuli (covers ears frequently). Hyposensitive to proprioceptive input.
Strengths: Strong visual-spatial reasoning. Excellent memory for patterns. Responds well to routine.
Challenges: Emotional regulation. Transitions between activities. Fine motor grip strength.
Recommendations: Daily proprioceptive activities, weighted blanket during work sessions, 10-min movement breaks.`;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AGENT 1 — Data Extractor & Relevance Checker
    // ─────────────────────────────────────────────────────────────────────────
    console.log("\n[Agent 1] 🤖 Data Extractor running...");
    const agent1Raw = await callGroq(
      `You are a clinical data extraction specialist for a pediatric neurodevelopmental platform.
      Your job is to extract structured data from uploaded documents.
      
      VALIDATION RULES — BE VERY LENIENT:
      - You MUST set "is_valid_clinical_document" to TRUE for ANY document that could reasonably be related to a child's health, development, education, therapy, or wellbeing.
      - This includes but is not limited to: medical reports, clinical evaluations, therapy notes, IEPs, school reports, developmental assessments, psychological evaluations, speech therapy reports, occupational therapy reports, neurological reports, pediatric reports, prescriptions, referral letters, progress notes, diagnostic summaries, and ANY document from a healthcare or educational professional.
      - Documents in ANY language (English, French, Arabic, etc.) are valid.
      - Even if OCR quality is poor or text is partially garbled, if you can identify ANY medical, clinical, therapeutic, or educational keywords, mark it as VALID.
      - ONLY mark as invalid if the text is CLEARLY and OBVIOUSLY unrelated to health/education (e.g., a cooking recipe, a news article about politics, a fiction story, an invoice for electronics).
      - When in doubt, ALWAYS mark as VALID (is_valid_clinical_document = true).
      
      IMPORTANT: Return ONLY valid JSON. No explanations. No markdown.
      DISCLAIMER: This is for educational purposes only, not medical diagnosis.`,
      `Analyze this text and extract clinical data:
      "${extractedText}"
      
      Return this exact JSON:
      {
        "is_valid_clinical_document": true,
        "invalid_reason": "",
        "primary_diagnosis": "string or 'Not specified'",
        "secondary_diagnoses": ["string"],
        "age_at_assessment": "string or 'Not specified'",
        "assessment_date": "string or 'Not specified'",
        "assessing_professional": "string or 'Not specified'",
        "report_type": "OT | Speech | Neuro | IEP | Other"
      }`,
      groqApiKey,
    );
    const agent1 = safeParse(agent1Raw, { is_valid_clinical_document: true });
    
    // Force valid if the extracted text has reasonable length (likely a real document)
    if (extractedText.length > 50) {
      agent1.is_valid_clinical_document = true;
    }
    
    if (agent1.is_valid_clinical_document === false) {
      console.warn(`[Agent 1] ❌ Invalid document: ${agent1.invalid_reason}`);
      if (document_id) {
        await supabase.from("documents").update({ status: "error" }).eq("id", document_id);
      }
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: `Document rejected by AI: This does not appear to be a valid clinical or medical report. \n\nReason: ${agent1.invalid_reason}` 
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
      );
    }
    
    console.log(`[Agent 1] ✅ Valid report. Extracted diagnosis: ${agent1.primary_diagnosis || "Unknown"}`);

    // ─────────────────────────────────────────────────────────────────────────
    // AGENT 2 — Developmental Profiler: Strengths & Challenges
    // ─────────────────────────────────────────────────────────────────────────
    console.log("\n[Agent 2] 🤖 Developmental Profiler running...");
    const agent2Raw = await callGroq(
      `You are a clinical data synthesizer. Extract ALL findings, strengths, challenges, and neutral facts from the text.
      CRITICAL INSTRUCTION: You MUST extract information for EVERY possible domain mentioned in the text. 
      If there are facts about Genetics, Brain Development, Environment, Daily Living, or Behavior, you MUST extract them. 
      If a fact is neutral (e.g. "MRI is normal" or "Lives in a 2-story house"), place it inside the "strengths" array.
      IMPORTANT: Return ONLY valid JSON.`,
      `Identify all findings from:
      "${extractedText}"
      
      Return this exact JSON:
      {
        "strengths": [
          { "label": "string (e.g., 'Brain MRI', 'Home Layout')", "description": "string", "domain": "Cognitive | Behavioral | Social | Motor | Communication | Sensory | Academic | Genetic | Environment | Brain | DailyLiving" }
        ],
        "challenges": [
          { "label": "string", "description": "string", "domain": "Cognitive | Behavioral | Social | Motor | Communication | Sensory | Academic | Genetic | Environment | Brain | DailyLiving" }
        ]
      }`,
      groqApiKey,
    );
    const agent2 = safeParse(agent2Raw, { strengths: [], challenges: [] });
    console.log(`[Agent 2] ✅ Found ${agent2.strengths?.length || 0} strengths, ${agent2.challenges?.length || 0} challenges.`);

    // ─────────────────────────────────────────────────────────────────────────
    // AGENT 3 — Sensory Profiler: Sensory processing patterns
    // ─────────────────────────────────────────────────────────────────────────
    console.log("\n[Agent 3] 🤖 Sensory Profiler running...");
    const agent3Raw = await callGroq(
      `You are a sensory processing specialist. Identify sensory patterns from clinical observations.
      IMPORTANT: Return ONLY valid JSON. Educational purposes only, not diagnosis.`,
      `Analyze sensory processing from:
      "${extractedText}"
      
      Return this exact JSON:
      {
        "sensory_profile": {
          "auditory": "hypersensitive | hyposensitive | typical | unknown",
          "visual": "hypersensitive | hyposensitive | typical | unknown",
          "tactile": "hypersensitive | hyposensitive | typical | unknown",
          "proprioceptive": "hypersensitive | hyposensitive | typical | unknown",
          "vestibular": "hypersensitive | hyposensitive | typical | unknown",
          "interoceptive": "hypersensitive | hyposensitive | typical | unknown",
          "sensory_notes": "string"
        },
        "communication_profile": {
          "primary_mode": "verbal | AAC | PECS | nonverbal | gestural | mixed",
          "receptive_level": "1-step | 2-step | complex | unknown",
          "expressive_notes": "string",
          "aac_tools": ["string"]
        }
      }`,
      groqApiKey,
    );
    const agent3 = safeParse(agent3Raw, { sensory_profile: {}, communication_profile: {} });
    console.log(`[Agent 3] ✅ Sensory profile mapped. Auditory: ${agent3.sensory_profile?.auditory || "unknown"}`);

    // ─────────────────────────────────────────────────────────────────────────
    // AGENT 4 — Motor & Reflex Analyzer
    // ─────────────────────────────────────────────────────────────────────────
    console.log("\n[Agent 4] 🤖 Motor & Reflex Analyzer running...");
    const agent4Raw = await callGroq(
      `You are a motor development specialist. Analyze motor patterns and primitive reflex retention.
      IMPORTANT: Return ONLY valid JSON. Educational purposes only.
      Score reflexes 0-4: 0=integrated, 1=minimal, 2=emerging, 3=moderate, 4=severe retention.`,
      `Analyze motor patterns from:
      "${extractedText}"
      
      Return this exact JSON:
      {
        "motor_reflexes": [
          { "name": "Moro", "score": 0, "label": "Integrated | Minimal | Emerging | Moderate | Retained (Severe)", "confidence": "INFERRED | POSSIBLE | DEFINITIVE" },
          { "name": "ATNR", "score": 0, "label": "Integrated | Minimal | Emerging | Moderate | Retained (Severe)", "confidence": "INFERRED | POSSIBLE | DEFINITIVE" },
          { "name": "STNR", "score": 0, "label": "Integrated | Minimal | Emerging | Moderate | Retained (Severe)", "confidence": "INFERRED | POSSIBLE | DEFINITIVE" },
          { "name": "TLR", "score": 0, "label": "Integrated | Minimal | Emerging | Moderate | Retained (Severe)", "confidence": "INFERRED | POSSIBLE | DEFINITIVE" },
          { "name": "Spinal Galant", "score": 0, "label": "Integrated | Minimal | Emerging | Moderate | Retained (Severe)", "confidence": "INFERRED | POSSIBLE | DEFINITIVE" },
          { "name": "Palmar Grasp", "score": 0, "label": "Integrated | Minimal | Emerging | Moderate | Retained (Severe)", "confidence": "INFERRED | POSSIBLE | DEFINITIVE" }
        ],
        "motor_notes": "string"
      }`,
      groqApiKey,
    );
    const agent4 = safeParse(agent4Raw, { motor_reflexes: [] });
    console.log(`[Agent 4] ✅ Analyzed ${agent4.motor_reflexes?.length || 0} reflexes.`);

    // ─────────────────────────────────────────────────────────────────────────
    // AGENT 5 — Cross-Report Synthesizer: Functional wellness
    // ─────────────────────────────────────────────────────────────────────────
    console.log("\n[Agent 5] 🤖 Cross-Report Synthesizer running...");
    const agent5Raw = await callGroq(
      `You are a multi-disciplinary clinical synthesizer. Connect patterns across domains.
      IMPORTANT: Return ONLY valid JSON. Educational purposes only.`,
      `Based on this clinical profile summary:
      - Strengths: ${JSON.stringify(agent2.strengths?.slice(0, 3))}
      - Challenges: ${JSON.stringify(agent2.challenges?.slice(0, 3))}
      - Sensory: ${JSON.stringify(agent3.sensory_profile)}
      - Reflexes: ${JSON.stringify(agent4.motor_reflexes)}
      - Source text snippet: "${extractedText.slice(0, 500)}"
      
      Return this exact JSON:
      {
        "functional_wellness": [
          { "title": "string", "description": "string", "confidence": "INFERRED | POSSIBLE | DEFINITIVE" }
        ],
        "cross_report_insights": [
          { "insight": "string", "domains_linked": ["string"] }
        ]
      }`,
      groqApiKey,
    );
    const agent5 = safeParse(agent5Raw, { functional_wellness: [], cross_report_insights: [] });
    console.log(`[Agent 5] ✅ Generated ${agent5.functional_wellness?.length || 0} functional wellness insights.`);

    // ─────────────────────────────────────────────────────────────────────────
    // AGENT 6 — Strategy Recommender: Home Plan & Game Calibration
    // ─────────────────────────────────────────────────────────────────────────
    console.log("\n[Agent 6] 🤖 Strategy Recommender running...");
    const agent6Raw = await callGroq(
      `You are a therapeutic strategy specialist. Create actionable home plans and game calibration settings.
      IMPORTANT: Return ONLY valid JSON. All recommendations are educational only.`,
      `Create strategies based on:
      - Primary diagnosis: ${agent1.primary_diagnosis}
      - Key challenges: ${JSON.stringify(agent2.challenges?.map((c: { label: string }) => c.label))}
      - Sensory profile: auditory=${agent3.sensory_profile?.auditory}, tactile=${agent3.sensory_profile?.tactile}
      - Retained reflexes: ${JSON.stringify(agent4.motor_reflexes?.filter((r: { score: number }) => r.score >= 2).map((r: { name: string; score: number }) => r.name))}
      
      Return this exact JSON:
      {
        "home_plan": {
          "daily_routine": [
            { "time": "Morning | Midday | Evening", "activity": "string", "duration_min": 10, "rationale": "string" }
          ],
          "environment_tips": ["string"],
          "communication_tips": ["string"]
        },
        "calibration_parameters": {
          "recommended_keyboard_size": "Big keys | Medium keys | Standard keys",
          "recommended_difficulty": "Easy | Medium | Complex - Words",
          "session_duration_min": 10,
          "break_frequency_min": 5,
          "rationale": "string"
        },
        "care_navigator": {
          "priority_referrals": ["string"],
          "next_assessment_domains": ["string"],
          "urgency": "Routine | Soon | Urgent"
        }
      }`,
      groqApiKey,
    );
    const agent6 = safeParse(agent6Raw, { home_plan: {}, calibration_parameters: {}, care_navigator: {} });
    console.log(`[Agent 6] ✅ Home plan and calibration generated.`);

    // ─────────────────────────────────────────────────────────────────────────
    // STEP 3 — Calculate dynamic Completeness based on 12 Domains
    // ─────────────────────────────────────────────────────────────────────────
    let domainsFilled = 0;
    const allFindings = [...(agent2.strengths || []), ...(agent2.challenges || [])];
    
    // Check all 12 domains explicitly:
    if (allFindings.length > 0) domainsFilled++; // 1. Developmental
    if (allFindings.some(f => f.domain === 'Academic')) domainsFilled++; // 2. Academic
    if (allFindings.some(f => f.domain?.startsWith('Behavior') || f.domain?.startsWith('Behaviour'))) domainsFilled++; // 3. Behavioral
    if (agent6.home_plan?.daily_routine?.length > 0) domainsFilled++; // 4. Support Plan
    if (Object.keys(agent3.sensory_profile || {}).length > 0) domainsFilled++; // 5. Sensory
    if (agent5.functional_wellness?.length > 0) domainsFilled++; // 6. Functional Wellness
    if (allFindings.some(f => f.domain === 'Genetic')) domainsFilled++; // 7. Genetic
    if (allFindings.some(f => f.domain === 'Environment')) domainsFilled++; // 8. Environment
    if (agent4.motor_reflexes?.length > 0) domainsFilled++; // 9. Motor Reflexes
    if (Object.keys(agent3.communication_profile || {}).length > 0) domainsFilled++; // 10. Communication
    if (allFindings.some(f => f.domain === 'Brain')) domainsFilled++; // 11. Brain
    if (allFindings.some(f => f.domain === 'DailyLiving')) domainsFilled++; // 12. Daily Living

    let completeness = Math.round((domainsFilled / 12) * 100);
    console.log(`\n[Score] 📊 Atlas completeness: ${completeness}%`);

    // ─────────────────────────────────────────────────────────────────────────
    // STEP 4 — Save the full profile to atlas_profiles
    // ─────────────────────────────────────────────────────────────────────────
    console.log("\n[DB] 💾 Saving full Atlas profile to Supabase...");
    const { error: upsertError } = await supabase.from("atlas_profiles").upsert(
      {
        child_id: child_id,
        completeness_percentage: completeness,
        strengths: agent2.strengths || [],
        challenges: agent2.challenges || [],
        communication_profile: agent3.communication_profile || {},
        sensory_profile: agent3.sensory_profile || {},
        functional_wellness: agent5.functional_wellness || [],
        motor_reflexes: agent4.motor_reflexes || [],
        cross_report_insights: agent5.cross_report_insights || [],
        home_plan: agent6.home_plan || {},
        calibration_parameters: agent6.calibration_parameters || {},
        care_navigator: agent6.care_navigator || {},
        last_updated_at: new Date().toISOString(),
      },
      { onConflict: "child_id" },
    );

    if (upsertError) throw new Error(`DB upsert failed: ${upsertError.message}`);
    console.log("[DB] ✅ Atlas profile saved successfully.");

    // ─────────────────────────────────────────────────────────────────────────
    // STEP 5 — Mark document as processed
    // ─────────────────────────────────────────────────────────────────────────
    if (document_id) {
      await supabase.from("documents").update({ status: "definitive" }).eq("id", document_id);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // STEP 6 — Delete the raw file (RGPD/HIPAA compliance)
    // ─────────────────────────────────────────────────────────────────────────
    // NOTE: Only delete if configured — keep for demo purposes.
    // const { error: deleteError } = await supabase.storage.from('patient-documents').remove([file_path]);
    // if (deleteError) console.warn('[RGPD] Warning: Could not delete raw file:', deleteError.message);

    console.log("\n🎉 Pipeline complete!");

    return new Response(
      JSON.stringify({
        success: true,
        completeness,
        profile_summary: {
          diagnosis: agent1.primary_diagnosis,
          strengths_count: agent2.strengths?.length,
          motor_flags: agent4.motor_reflexes?.filter((r: { score: number }) => r.score >= 2).map((r: { name: string }) => r.name),
          keyboard_recommendation: agent6.calibration_parameters?.recommended_keyboard_size,
        },
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (error) {
    console.error("❌ Pipeline error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 },
    );
  }
});
